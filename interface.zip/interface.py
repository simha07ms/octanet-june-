import sys

class User:
    def _init_(self, user_id, pin):
        self.user_id = user_id
        self.pin = pin
        self.balance = 0
        self.transaction_history = []

    def verify_pin(self, pin):
        return self.pin == pin

    def add_transaction(self, transaction):
        self.transaction_history.append(transaction)

class ATM:
    def _init_(self):
        self.users = {}
        self.current_user = None

    def add_user(self, user):
        self.users[user.user_id] = user

    def authenticate_user(self, user_id, pin):
        user = self.users.get(user_id)
        if user and user.verify_pin(pin):
            self.current_user = user
            print("Login successful.")
            return True
        print("Invalid user ID or PIN.")
        return False

    def display_menu(self):
        print("\nATM Menu:")
        print("1. Transaction History")
        print("2. Withdraw")
        print("3. Deposit")
        print("4. Transfer")
        print("5. Quit")

    def handle_option(self, option):
        if option == '1':
            self.show_transaction_history()
        elif option == '2':
            self.withdraw()
        elif option == '3':
            self.deposit()
        elif option == '4':
            self.transfer()
        elif option == '5':
            print("Thank you for using the ATM. Goodbye!")
            sys.exit()
        else:
            print("Invalid option. Please try again.")

    def show_transaction_history(self):
        print("\nTransaction History:")
        for transaction in self.current_user.transaction_history:
            print(transaction)

    def withdraw(self):
        amount = float(input("Enter amount to withdraw: "))
        if amount > self.current_user.balance:
            print("Insufficient balance.")
        else:
            self.current_user.balance -= amount
            self.current_user.add_transaction(f"Withdrew {amount}")
            print(f"{amount} withdrawn successfully.")

    def deposit(self):
        amount = float(input("Enter amount to deposit: "))
        self.current_user.balance += amount
        self.current_user.add_transaction(f"Deposited {amount}")
        print(f"{amount} deposited successfully.")

    def transfer(self):
        recipient_id = input("Enter recipient user ID: ")
        recipient = self.users.get(recipient_id)
        if not recipient:
            print("Recipient not found.")
            return
        amount = float(input("Enter amount to transfer: "))
        if amount > self.current_user.balance:
            print("Insufficient balance.")
        else:
            self.current_user.balance -= amount
            recipient.balance += amount
            self.current_user.add_transaction(f"Transferred {amount} to {recipient_id}")
            recipient.add_transaction(f"Received {amount} from {self.current_user.user_id}")
            print(f"{amount} transferred successfully.")

def main():
    atm = ATM()
    
    # Adding some sample users
    atm.add_user(User('user1', '1234'))
    atm.add_user(User('user2', '5678'))

    while True:
        user_id = input("Enter user ID: ")
        pin = input("Enter PIN: ")
        
        if atm.authenticate_user(user_id, pin):
            while True:
                atm.display_menu()
                option = input("Choose an option: ")
                atm.handle_option(option)

if _name_ == "_main_":
    main()